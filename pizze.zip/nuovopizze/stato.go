package main

import (
	"errors"
	"sync"
)

type Ordini struct {
	ordini       map[int]*Ordine
	ultimoIndice int
	lock         *sync.RWMutex
}

func NewOrdini() Ordini {
	return Ordini{
		ordini:       map[int]*Ordine{},
		ultimoIndice: 1,
		lock:         &sync.RWMutex{},
	}
}

type OrdineConIndice struct {
	*Ordine
	Indice int
}

func (o *Ordini) List() []OrdineConIndice {
	o.lock.RLock()
	defer o.lock.RUnlock()

	output := make([]OrdineConIndice, 0, len(o.ordini))
	for indice, ordine := range o.ordini {
		output = append(output, OrdineConIndice{ordine, indice})
	}
	return output
}

func (o *Ordini) Get(indice int) (OrdineConIndice, error) {
	o.lock.RLock()
	defer o.lock.RUnlock()

	ord, ok := o.ordini[indice]
	if !ok {
		return OrdineConIndice{}, errors.New("ordine inesistente")
	}

	return OrdineConIndice{ord, indice}, nil
}

func (o *Ordini) Delete(indice int) {
	o.lock.Lock()
	defer o.lock.Unlock()

	delete(o.ordini, indice)
}

func (o *Ordini) Add(ord *Ordine) error {
	o.lock.Lock()
	defer o.lock.Unlock()

	_, esisteGia := o.ordini[o.ultimoIndice]
	if esisteGia {
		return errors.New("indice già occupato")
	}

	o.ordini[o.ultimoIndice] = ord
	o.ultimoIndice += 1
	return nil
}

func (o *Ordini) Set(ord *Ordine, indice int) {
	o.lock.Lock()
	defer o.lock.Unlock()

	o.ordini[indice] = ord
}
