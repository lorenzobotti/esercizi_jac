const apiUrl = `http://localhost:8080/ordini`

const selectOrdini = document.getElementById('select-ordini')
const sezioneCrea = document.getElementById('sezione-crea')
const formOrdine = document.getElementById('form-ordine')
const titoloForm = document.getElementById('titolo-form')
const bottoneCrea = document.getElementById('bottone-crea')
const bottoneCerca = document.getElementById('bottone-cerca')
const bottoneRicarica = document.getElementById('bottone-ricarica')
const bottoneElimina = document.getElementById('bottone-elimina')
const queryRicerca = document.getElementById('query')
const campoRicerca = document.getElementById('campo-ricerca')


let ordini = [];
let modalità = 'nuovo';

function popolaOrdini() {
    selectOrdini.innerHTML = '';
    fetch(apiUrl)
        .then(res => res.json())
        .then(res => {
            ordini = res;

            res.forEach(ordine => {
                let opt = document.createElement('option')
                opt.innerText = `${ordine.Pizza} per ${ordine.Nome} ${ordine.Cognome}`
                opt.value = ordine.Indice
                selectOrdini.appendChild(opt)
            })
        })
}

function cambiaModalità(mod) {
    modalità = mod

    if (modalità == 'nuovo') {
        titoloForm.innerText = 'Crea ordine'
        bottoneCrea.style.display = 'none'
    } else if (modalità == 'modifica') {
        titoloForm.innerText = 'Modifica ordine'
        bottoneCrea.style.display = 'block'
    }

    formOrdine["pizza"].value = ''
    formOrdine["nome"].value = ''
    formOrdine["cognome"].value = ''
    formOrdine["via"].value = ''
    formOrdine["comune"].value = ''
    formOrdine["numero-civico"].value = ''
    aggiornaOrologio()
}

selectOrdini.addEventListener('input', event => {
    fetch(`${apiUrl}/${selectOrdini.value}`)
        .then(res => res.json())
        .then(res => {
            cambiaModalità('modifica')

            formOrdine["pizza"].value = res.Pizza
            formOrdine["nome"].value = res.Nome
            formOrdine["cognome"].value = res.Cognome
            formOrdine["via"].value = res.Via
            formOrdine["comune"].value = res.Comune
            formOrdine["numero-civico"].value = res.NumeroCivico

            inserisciOra(res.Orario)
        })
})

formOrdine.addEventListener('submit', event => {
    event.preventDefault()

    const body = {
        Pizza: formOrdine["pizza"].value,
        Nome: formOrdine["nome"].value,
        Cognome: formOrdine["cognome"].value,
        Via: formOrdine["via"].value,
        Comune: formOrdine["comune"].value,
        NumeroCivico: formOrdine["numero-civico"].value,
        Orario: oraDaForm(),
    }

    const url = modalità == 'nuovo' ? `${apiUrl}` : `${apiUrl}/${selectOrdini.value}`
    const method = modalità == 'nuovo' ? 'POST' : 'PUT'
    fetch(url, {
        method,
        body: JSON.stringify(body)
    })
        .then(res => {
            popolaOrdini()
        })
})

bottoneCrea.addEventListener('click', () => cambiaModalità(modalità == 'nuovo' ? 'modifica' : 'nuovo'))
bottoneCerca.addEventListener('click', () => {
    const campo = campoRicerca.value;
    const query = queryRicerca.value;

    selectOrdini.innerHTML = ''
    ordini
        .map(ordine => { return { ordine: ordine, campo: ordine[campo] } })
        .filter(campo => campo.campo.includes(query))
        .forEach(ordine => {
            let opt = document.createElement('option')
            opt.innerText = `${ordine.ordine.Pizza} per ${ordine.ordine.Nome} ${ordine.ordine.Cognome}`
            opt.value = ordine.ordine.Indice
            selectOrdini.appendChild(opt)
        })

})
bottoneRicarica.addEventListener('click', popolaOrdini)
bottoneElimina.addEventListener('click', () => {
    fetch(`${apiUrl}/${selectOrdini.value}`, {
        method: 'DELETE'
    })
        .then(popolaOrdini)
})

function oraDaForm() {
    const [ora, minuti] = formOrdine['ora'].value.split(':')
    return formOrdine['data'].value + `T${ora}:${minuti}:00Z00:00`
}

function aggiornaOrologio() {
    const zeroPad = (num, places) => String(num).padStart(places, '0')
    const adesso = new Date();

    const anno = zeroPad(adesso.getFullYear(), 4);
    const mese = zeroPad(adesso.getMonth(), 2);
    const giorno = zeroPad(adesso.getDate(), 2);

    formOrdine['data'].value = `${anno}-${mese}-${giorno}`

    const ora = zeroPad(adesso.getHours(), 2)
    const minuti = zeroPad(adesso.getMinutes(), 2)
    const secondi = zeroPad(adesso.getSeconds(), 2)

    formOrdine['ora'].value = `${ora}:${minuti}:00`
}

function inserisciOra(input) {
    const [data, oraERoba] = input.split('T')
    formOrdine['data'].value = data

    const [ora, rovaCheNonServe] = oraERoba.split('Z')
    formOrdine['ora'].value = ora
}

popolaOrdini()
aggiornaOrologio()