package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

type HTTPApi struct {
	ordini *Ordini
	router *mux.Router
}

func NewHttpApi(ordini *Ordini) *HTTPApi {
	api := &HTTPApi{
		ordini,
		mux.NewRouter(),
	}
	api.router.HandleFunc("/ordini", api.List).Methods(http.MethodGet)
	api.router.HandleFunc("/ordini", api.Add).Methods(http.MethodPost)
	api.router.HandleFunc("/ordini/{index}", api.Get).Methods(http.MethodGet)
	api.router.HandleFunc("/ordini/{index}", api.Set).Methods(http.MethodPut)
	api.router.HandleFunc("/ordini/{index}", api.Delete).Methods(http.MethodDelete)

	return api
}

func (h *HTTPApi) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	fmt.Println("serving http")
	h.router.ServeHTTP(w, r)

	fmt.Println("served")
}

func (h *HTTPApi) Get(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	indice, err := strconv.Atoi(params["index"])
	if err != nil {
		http.Error(w, "Indice non valido", http.StatusBadRequest)
		return
	}

	ordine, err := h.ordini.Get(indice)
	if err != nil {
		http.Error(w, "Ordine Inesistente", http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(ordine)
}

func (h *HTTPApi) List(w http.ResponseWriter, r *http.Request) {
	ordini := h.ordini.List()
	json.NewEncoder(w).Encode(ordini)
}

func (h *HTTPApi) Add(w http.ResponseWriter, r *http.Request) {
	fmt.Println("add")
	ord := &Ordine{}
	err := json.NewDecoder(r.Body).Decode(&ord)
	if err != nil {
		http.Error(w, "Input non valido", http.StatusBadRequest)
		return
	}

	err = h.ordini.Add(ord)
	if err != nil {
		http.Error(w, "Input già esistente", http.StatusNotAcceptable)
		return
	}
}

func (h *HTTPApi) Set(w http.ResponseWriter, r *http.Request) {
	ord := &Ordine{}
	err := json.NewDecoder(r.Body).Decode(&ord)
	if err != nil {
		http.Error(w, "Input non valido", http.StatusBadRequest)
	}

	params := mux.Vars(r)
	indice, err := strconv.Atoi(params["index"])
	if err != nil {
		http.Error(w, "Indice non valido", http.StatusBadRequest)
		return
	}

	h.ordini.Set(ord, indice)
}

func (h *HTTPApi) Delete(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	indice, err := strconv.Atoi(params["index"])
	if err != nil {
		http.Error(w, "Indice non valido", http.StatusBadRequest)
		return
	}

	fmt.Println("delete: cancello indice", indice)

	h.ordini.Delete(indice)
}
