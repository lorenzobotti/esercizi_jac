package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
)

func TestPostThenGet(t *testing.T) {
	ordini := NewOrdini()
	api := NewHttpApi(&ordini)

	ordine := Ordine{
		Nome:    "Lorenzo",
		Cognome: "Botti",
		Via:     "Valletta",
		Pizza:   "Margherita",
	}
	postPayload, _ := json.Marshal(ordine)
	postReq, err := http.NewRequest(http.MethodPost, "http://locahost:8080/ordini", bytes.NewBuffer(postPayload))
	if err != nil {
		t.Fatal(err)
	}
	postRes := httptest.NewRecorder()
	api.ServeHTTP(postRes, postReq)
	if api.ordini.ultimoIndice == 1 {
		t.Fatal("indice:", api.ordini.ultimoIndice)
	}

	getReq, _ := http.NewRequest(http.MethodGet, "http://locahost:8080/ordini/2", nil)
	getRes := httptest.NewRecorder()
	api.ServeHTTP(getRes, getReq)

	io.Copy(os.Stdout, getRes.Body)
}
