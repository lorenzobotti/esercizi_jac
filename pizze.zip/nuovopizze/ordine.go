package main

type Ordine struct {
	Pizza        string
	Nome         string
	Cognome      string
	Comune       string
	Via          string
	NumeroCivico string
	Orario       string
}
