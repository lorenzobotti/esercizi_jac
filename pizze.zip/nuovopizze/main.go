package main

import (
	"fmt"
	"net/http"
)

func main() {
	ordini := NewOrdini()
	api := NewHttpApi(&ordini)

	fmt.Println("fatal:", http.ListenAndServe(":8080", &CORSMiddleware{api}))
}
