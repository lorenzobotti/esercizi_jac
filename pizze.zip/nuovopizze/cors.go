package main

import (
	"net/http"
)

type CORSMiddleware struct {
	Then http.Handler
}

func (c *CORSMiddleware) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "DELETE, POST, PUT, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "X-PINGOTHER, Content-Type")
	w.Header().Set("Access-Control-Max-Age", "86400")

	if r.Method != http.MethodOptions {
		c.Then.ServeHTTP(w, r)
	}
}
