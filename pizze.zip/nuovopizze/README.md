Per compilare il server serve il compilatore Go dalla versione 1.17 in poi, ma sospetto possa funzionare anche con versioni precendenti.
Compilazione (partendo dalla cartella del progetto)
```
go run .
```
Se non funzionasse provare
```
go run *.go
```

Non ho avuto il tempo di far servire al backend la GUI. Essa risiede in frontend/index.html.
Nota: i risultati della ricerca sono mostrati nella stessa `<select>` degli ordini. Per tornare agli ordini normali basta cliccare "Aggiorna ordini" in alto